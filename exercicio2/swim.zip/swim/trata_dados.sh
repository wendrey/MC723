for D in `find ~/Documents/exer5/trace_3*.out`
do

	FILE=$(basename $D)
	IFS='_' read -r TRACE T CACHE C BLOCK B ASS AUX <<< "$FILE"
	A=${AUX%.out}

	echo -n "$C,$B,$A," >> "trace3.csv" 
	awk '{if(($1 $2 $3)==("Demand" "miss" "rate")) printf "%f,", $4}' "$FILE" >> "trace3.csv"
	echo "" >> "trace3.csv"

done
