for D in `find ~/Documents/exer3/trace_1*.out`
do

	FILE=$(basename $D)
	IFS='_' read -r TRACE T CACHE C BLOCK B ASS AUX <<< "$FILE"
	A=${AUX%.out}

	echo -n "$C,$B,$A," >> "trace1.csv" 
	awk '{if(($1 $2 $3)==("Demand" "miss" "rate")) printf "%f,", $4}' "$FILE" >> "trace1.csv"
	echo "" >> "trace1.csv"

done
