#!/bin/bash

TRACE[0]="-trname twolf_m2b -maxtrace 20"
TRACE[1]="-trname equake_m2b -maxtrace 20"
TRACE[2]="-trname art_m2b -maxtrace 20"
TRACE[3]="-trname swim_m2b -maxtrace 20"

CACHE_SIZE[0]="16K"
CACHE_SIZE[1]="32K"
CACHE_SIZE[2]="64K"
CACHE_SIZE[3]="128K"
CACHE_SIZE[4]="256K"
CACHE_SIZE[5]="512K"

BLOCK_SIZE[0]="1"
BLOCK_SIZE[1]="2"
BLOCK_SIZE[2]="4"
BLOCK_SIZE[3]="8"
BLOCK_SIZE[4]="16"
BLOCK_SIZE[5]="32"

ASSOCIATIVITY[0]="1"
ASSOCIATIVITY[1]="2"
ASSOCIATIVITY[2]="4"
ASSOCIATIVITY[3]="8"
ASSOCIATIVITY[4]="16"
ASSOCIATIVITY[5]="32"

REPLACE[0]="l"
REPLACE[1]="f"
REPLACE[2]="r"

DINERO_PATH="/home/staff/lucas/mc723/dinero4sbc/dineroIV"
FORMAT="-informat s"
INST="-l1-isize"
DATA="-l1-dsize"
INSTBLOCK="-l1-ibsize"
DATABLOCK="-l1-dbsize"
INSTASS="-l1-iassoc"
DATAASS="-l1-dassoc"
INFO="-l1-iccc -l1-dccc"
OUTPUT_PATH="/home/ec2013/ra148234/Documents/exer3/"

for((T=1;T<2;T++)) do # trace
	for((I=0;I<6;I++)) do # cache
		for((J=0;J<6;J++)) do # block
			for((K=0;K<6;K++)) do # assoc

				FILE="trace_${T}_cache_${CACHE_SIZE[$I]}_block_${BLOCK_SIZE[$J]}_ass_${ASSOCIATIVITY[$K]}.out"
				echo $($DINERO_PATH ${TRACE[$T]} $FORMAT $INST ${CACHE_SIZE[$I]} $DATA ${CACHE_SIZE[$I]} $INSTBLOCK ${BLOCK_SIZE[$J]} $DATABLOCK ${BLOCK_SIZE[$J]} $INSTASS ${ASSOCIATIVITY[$K]} $DATAASS ${ASSOCIATIVITY[$K]} $INFO > $OUTPUT_PATH$FILE)
				
			done
		done
	done
done
