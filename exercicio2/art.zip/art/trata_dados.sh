for D in `find ~/Documents/exer4/trace_2*.out`
do

	FILE=$(basename $D)
	IFS='_' read -r TRACE T CACHE C BLOCK B ASS AUX <<< "$FILE"
	A=${AUX%.out}

	echo -n "$C,$B,$A," >> "trace2.csv" 
	awk '{if(($1 $2 $3)==("Demand" "miss" "rate")) printf "%f,", $4}' "$FILE" >> "trace2.csv"
	echo "" >> "trace2.csv"

done
